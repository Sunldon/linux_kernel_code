#include <linux/init.h>
#include <linux/module.h>
#include <asm/pgalloc.h>
#include <asm/pgtable.h>
#include <linux/thread_info.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/workqueue.h>
#include <linux/smp.h>
#include <asm-generic/percpu.h>
//#include <asm-generic/page.h>
#include <linux/mm_types.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Sun");

//extern pgd_t *pgd_alloc(struct mm_struct *mm);
#define waitname "waitforsome"

extern int kernel_thread(int (*fn)(void *), void *arg, unsigned long flags);
extern int task_nice(const struct task_struct *p);
extern void set_user_nice(struct task_struct *p, long nice);
extern asmlinkage void __sched schedule(void);
extern void __sched yield(void);
extern void *kmap(struct page *page);
extern struct page *alloc_pages_current(gfp_t gfp, unsigned order);

//extern void *page_address(struct page *page);



static int add(struct work_struct *work){
	printk(KERN_ALERT"work_data:%ld.\r\n",work->data.counter);
}

static int __init myModule_init(void)
{
	struct thread_info * ti;
	struct mm_struct *mm;

	struct task_struct* ts;
	ti=current_thread_info();
	
	struct pt_regs *regs;
	int i=1;
#if 0	
	struct work_struct *work;
	atomic_long_t data;
	data.counter=1;
	work->data=data;
	work->func=add;
	schedule_work(work);
#endif

#if 0
	long id=do_fork(CLONE_VFORK | CLONE_VM | SIGCHLD, regs->sp, regs,0, NULL, NULL);
	printk(KERN_ALERT"myModule init----fork_id:%d.\r\n",id);
#endif

#if 0
	long id=kernel_thread(add, regs,CLONE_VFORK);
	printk(KERN_ALERT"kernel_thread_id:%d.\r\n",id);
#endif
#if 0
	int nice=task_nice(ti->task);

    printk(KERN_ALERT"myModule init----pid:%d state:%d cpu:%d prio:%d static_prio:%d nice:%d policy:%d.\r\n",
			ti->task->pid,ti->task->state,ti->cpu,ti->cpu,ti->task->prio,ti->task->static_prio,nice,
			ti->task->policy);
#endif
	struct page *page=pfn_to_page(185024);
	struct zone *zone=page_zone(page);
	long int * addr=kmap(page);
	long int * maybe_addr=page_address(page);

	printk(KERN_ALERT"count:%d flag:%d zone_spanned_pages:%d present_pages:%d addr:%x maybe_addr:%x\n",
				page->_count.counter,page->flags,zone->spanned_pages,zone->present_pages,&addr,&maybe_addr);

	struct page *alloc_page=alloc_pages_current(__GFP_HIGHMEM,2);
	addr=kmap(alloc_page);
	maybe_addr=page_address(alloc_page);
	printk(KERN_ALERT"alloc_page_counter:%d ,addr:%x,maybe_addr:%x",alloc_page->_count.counter,&addr,&maybe_addr);
#if 0
	yield();
	
	ti=current_thread_info();
	printk(KERN_ALERT"after yield----pid:%d state:%d cpu:%d prio:%d static_prio:%d nice:%d policy:%d.\r\n",
			ti->task->pid,ti->task->state,ti->cpu,ti->cpu,ti->task->prio,ti->task->static_prio,nice,
			ti->task->policy);

	schedule();

	
	ti=current_thread_info();
	printk(KERN_ALERT"after schedule----pid:%d state:%d cpu:%d prio:%d static_prio:%d nice:%d policy:%d.\r\n",
			ti->task->pid,ti->task->state,ti->cpu,ti->cpu,ti->task->prio,ti->task->static_prio,nice,
			ti->task->policy);
#endif
        return 0;
}

static void __exit myModule_exit(void)
{
    printk(KERN_ALERT"myModule exit.\r\n");
}

module_init(myModule_init);
module_exit(myModule_exit);
