#include<linux/init.h>  
#include<linux/module.h>  
#include<linux/kernel.h>  
#include<linux/list.h>  
#include<linux/cpumask.h>  
#include<linux/completion.h>

  
static int __init mymod_init(void)  
{  
       complete((struct completion *)0xfffffffff8498000);
	   return 0;
}  
  
static void __exit mymod_exit(void)  
{  
	return 0;
}  
  
module_init(mymod_init);  
module_exit(mymod_exit);  
  
MODULE_AUTHOR("Zhangsk");  
MODULE_LICENSE("GPL");  
MODULE_DESCRIPTION("Why module can not be removed");  
